var actionString =
  "/version 3" +
  "/name [ 10" +
  "	7265736f6c7574696f6e" +
  "]" +
  "/isOpen 1" +
  "/actionCount 3" +
  "/action-1 {" +
  "	/name [ 6" +
  "		333030707069" +
  "	]" +
  "	/keyIndex 0" +
  "	/colorIndex 0" +
  "	/isOpen 1" +
  "	/eventCount 1" +
  "	/event-1 {" +
  "		/useRulersIn1stQuadrant 0" +
  "		/internalName (ai_plugin_rasterEffectSettings)" +
  "		/localizedName [ 32" +
  "			446f63756d656e742052617374657220456666656374732053657474696e6773" +
  "		]" +
  "		/isOpen 1" +
  "		/isOn 1" +
  "		/hasDialog 1" +
  "		/showDialog 0" +
  "		/parameterCount 7" +
  "		/parameter-1 {" +
  "			/key 1668246642" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 4" +
  "				434d594b" +
  "			]" +
  "			/value 5" +
  "		}" +
  "		/parameter-2 {" +
  "			/key 1685088558" +
  "			/showInPalette -1" +
  "			/type (integer)" +
  "			/value 300" +
  "		}" +
  "		/parameter-3 {" +
  "			/key 1651205988" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 11" +
  "				5472616e73706172656e74" +
  "			]" +
  "			/value 1" +
  "		}" +
  "		/parameter-4 {" +
  "			/key 1634494835" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-5 {" +
  "			/key 1835103083" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-6 {" +
  "			/key 1886613620" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-7 {" +
  "			/key 1885430884" +
  "			/showInPalette -1" +
  "			/type (unit real)" +
  "			/value 36.0" +
  "			/unit 592476268" +
  "		}" +
  "	}" +
  "}" +
  "/action-2 {" +
  "	/name [ 6" +
  "		313530707069" +
  "	]" +
  "	/keyIndex 0" +
  "	/colorIndex 0" +
  "	/isOpen 1" +
  "	/eventCount 1" +
  "	/event-1 {" +
  "		/useRulersIn1stQuadrant 0" +
  "		/internalName (ai_plugin_rasterEffectSettings)" +
  "		/localizedName [ 32" +
  "			446f63756d656e742052617374657220456666656374732053657474696e6773" +
  "		]" +
  "		/isOpen 1" +
  "		/isOn 1" +
  "		/hasDialog 1" +
  "		/showDialog 0" +
  "		/parameterCount 7" +
  "		/parameter-1 {" +
  "			/key 1668246642" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 4" +
  "				434d594b" +
  "			]" +
  "			/value 5" +
  "		}" +
  "		/parameter-2 {" +
  "			/key 1685088558" +
  "			/showInPalette -1" +
  "			/type (integer)" +
  "			/value 150" +
  "		}" +
  "		/parameter-3 {" +
  "			/key 1651205988" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 11" +
  "				5472616e73706172656e74" +
  "			]" +
  "			/value 1" +
  "		}" +
  "		/parameter-4 {" +
  "			/key 1634494835" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-5 {" +
  "			/key 1835103083" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-6 {" +
  "			/key 1886613620" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-7 {" +
  "			/key 1885430884" +
  "			/showInPalette -1" +
  "			/type (unit real)" +
  "			/value 36.0" +
  "			/unit 592476268" +
  "		}" +
  "	}" +
  "}" +
  "/action-3 {" +
  "	/name [ 5" +
  "		3732707069" +
  "	]" +
  "	/keyIndex 0" +
  "	/colorIndex 0" +
  "	/isOpen 1" +
  "	/eventCount 1" +
  "	/event-1 {" +
  "		/useRulersIn1stQuadrant 0" +
  "		/internalName (ai_plugin_rasterEffectSettings)" +
  "		/localizedName [ 32" +
  "			446f63756d656e742052617374657220456666656374732053657474696e6773" +
  "		]" +
  "		/isOpen 1" +
  "		/isOn 1" +
  "		/hasDialog 1" +
  "		/showDialog 0" +
  "		/parameterCount 7" +
  "		/parameter-1 {" +
  "			/key 1668246642" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 4" +
  "				434d594b" +
  "			]" +
  "			/value 5" +
  "		}" +
  "		/parameter-2 {" +
  "			/key 1685088558" +
  "			/showInPalette -1" +
  "			/type (integer)" +
  "			/value 72" +
  "		}" +
  "		/parameter-3 {" +
  "			/key 1651205988" +
  "			/showInPalette -1" +
  "			/type (enumerated)" +
  "			/name [ 11" +
  "				5472616e73706172656e74" +
  "			]" +
  "			/value 1" +
  "		}" +
  "		/parameter-4 {" +
  "			/key 1634494835" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-5 {" +
  "			/key 1835103083" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-6 {" +
  "			/key 1886613620" +
  "			/showInPalette -1" +
  "			/type (boolean)" +
  "			/value 0" +
  "		}" +
  "		/parameter-7 {" +
  "			/key 1885430884" +
  "			/showInPalette -1" +
  "			/type (unit real)" +
  "			/value 36.0" +
  "			/unit 592476268" +
  "		}" +
  "	}" +
  "}" +
  "";

/**
 * Creates and runs a temporary action from given .aia rawtext
 * @param {String} actionName Exact name of action
 * @param {String} actionSet Exact name of set containing action
 * @param {String} contents Raw .aia string of action file
 */
function runActionFromString(actionName, actionSet) {
  // Rather oddly AI always wants you to use a file instead of a string,
  // so we'll just create a temp file every time we need to:
  var tmp = File(Folder.desktop + "/tmp.aia");
  tmp.open("w");
  tmp.write(actionString);
  tmp.close();
  app.loadAction(tmp);
  app.doScript(actionName, actionSet, false);
  app.unloadAction(actionSet, "");
  // And remove the file:
  tmp.remove();
}
